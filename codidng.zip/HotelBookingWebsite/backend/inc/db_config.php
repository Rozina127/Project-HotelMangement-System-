<?php

$hname = 'localhost';
$uname = 'root';
$pass = '';
$db = 'hbwebsite';

// Database se connect hone ki koshish
$con = mysqli_connect($hname, $uname, $pass, $db);

// Agar connection nahi ho saka, toh error message display karo
if (!$con) {
    die("Database se connect nahi ho saka" . mysqli_connect_error());
}

// Select function jo prepared statements ka istemal karti hai
function select($sql, $values, $datatypes)
{
    global $con;

    // Prepared statement ko prepare karo
    if ($stmt = mysqli_prepare($con, $sql)) {
        // Prepared statement mein parameters bind karo
        mysqli_stmt_bind_param($stmt, $datatypes, ...$values);

        // Prepared statement ko execute karo
        if (mysqli_stmt_execute($stmt)) {
            // Prepared statement se result set hasil karo
            $result = mysqli_stmt_get_result($stmt);

            // Result set se data fetch karo (maan lijiye associative array fetch kar rahe hain)
            while ($row = mysqli_fetch_assoc($result)) {
                // Har row ka data process karo jaise ki print karna, etc.
                print_r($row); // Example: Har row ko print karna
            }

            // Result set ko free karo
            mysqli_free_result($result);
        } else {
            // Agar query execute nahi ho saki, toh error message display karo
            die("Query execute karne mein error: " . mysqli_error($con));
        }

        // Prepared statement ko band karo
        mysqli_stmt_close($stmt);
    } else {
        // Agar prepared statement prepare nahi ho saka, toh error message display karo
        die("Query prepare nahi ho sakti - Select");
    }
}

// Select function ka istemal ka example
$sql = "SELECT * FROM your_table WHERE your_condition = ?";
$values = ["your_parameter_value"];
$datatypes = "s"; // Maan liya gaya hai ki parameter ek string hai, aap apne requirement ke hisab se adjust karein

select($sql, $values, $datatypes);

// Database connection band karo jab kaam ho gaya
mysqli_close($con);
?>
