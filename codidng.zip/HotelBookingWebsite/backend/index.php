<?php 
	// Database configuration file include karna
	require('inc/db_config.php');

	// Filtration function for basic sanitization
	function filteration($data) {
		foreach ($data as $key => $value) {
			$data[$key] = trim($value);
			$data[$key] = stripslashes($value);
			$data[$key] = htmlspecialchars($value);
			// Add more sanitization as needed
		}
		return $data;
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin Login Panel</title>

	<?php 
		// Links file include karna jo required hai
		require('inc/links.php');
	?>

	<style>
		/* Styling ke liye CSS rules */
		div.login-form{
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
			width: 400px;
		}
	</style>
</head>
<body class="bg-light">

	<div class="login-form text-center rounded bg-white shadow overflow-none">
		
		<form method="POST">
			<h4 class="bg-dark text-white py-3">ADMIN LOGIN PANEL</h4>	
			<div class="p-4">
				<div class="mb-3">
    				<input name="admin_name" required type="text" class="form-control shadow-none text-center" placeholder="Admin Name">
  			  	</div>
  				<div class="mb-4">
    				<input name="admin_pass" required type="password" class="form-control shadow-none text-center" placeholder="Password">
  				</div>
  				<button name="login" type="submit" class="btn text-white bg-dark custom-bg shadow-none">LOGIN</button>
 			</div>
		</form>
	</div>

	<?php 
		// Login button press hone par check karna
		if (isset($_POST['login'])) 
		{
		 	// Form data ko filter karna
		 	$frm_data = filteration($_POST);
		 
		 	// Query banane ke liye placeholders ka istemal karna
		 	$query = "SELECT * FROM `admin_cred` WHERE `admin_name`=? AND `admin_pass` = ?";
		 	$values = [$frm_data['admin_name'], $frm_data['admin_pass']];
		 	$datatypes = "ss";

		 	// Select function ka istemal karke query execute karna
		 	select($query, $values, $datatypes);
		}
 	?>

	<?php 
		// Scripts file include karna jo required hai
		require('inc/scripts.php');
	?>
</body>
</html>
