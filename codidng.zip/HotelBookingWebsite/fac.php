<!DOCTYPE html>
<html>
<head>
	<title>Hotel Management System</title>
	<!-- CSS only -->
<?php require('inc/links.php'); ?>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"
/>
<link rel="stylesheet" type="text/css" href="css/common.css">
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<style>
  .pop:hover{
    border-top-color: var(--teal) !important;
    transform: scale(1.03);
    transition: all 0.3s;
  }
</style>

</head>
<body>

<?php require('inc/header.php'); ?>

<div class="my-5 px-4">
  <h2 class="fw-bold h-font text-center">OUR FACILITIES</h2>

  <div class="h-line bg-dark"></div>
  <p class="text-center mt-3">
  Welcome to Urban Oasis Suites, where urban comfort blends with modern elegance. Situated in the central region of Islamabad, our boutique hotel provides an impeccable fusion of opulence and peace.
  </p>
</div>

<div class="container">
  <div class="row">
    <div class="col-lg-4 col-md-6 mb-5 px-4">
      <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
        <div class="d-flex align-items-center mb-2">
          <img src="images/facilities/Wifi.svg" width="40px">
          <h5 class="m-0 ms-3">Wifi</h5>
        </div>  
          <p>
          Because we at Urban Oasis Suites know how important it is to stay connected, our strong Wi-Fi infrastructure is built to quickly and effectively meet all of your digital needs.
          </p> 
      </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-5 px-4">
      <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
        <div class="d-flex align-items-center mb-2">
          <img src="images/images/gallery-3.png" width="40px">
          <h5 class="m-0 ms-3">Cleanliness</h5>
        </div>  
          <p>
          Our first priorities are your safety and comfort. For your peace of mind, our committed housekeeping staff makes sure that every area of Urban Oasis Suites is clean and sanitised.
          </p> 
      </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-5 px-4">
      <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
        <div class="d-flex align-items-center mb-2">
          <img src="images/images/w1.jpg" width="40px">
          <h5 class="m-0 ms-3">24/7 Reception and Security</h5>
        </div>  
          <p>
          Our on-duty security staff uses cutting edge monitoring tools to make sure you're safe at all times. You can relax knowing that we place equal importance on your safety and comfort.
          </p> 
      </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-5 px-4">
      <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
        <div class="d-flex align-items-center mb-2">
          <img src="images/images/img1.jpg.jpg" width="40px">
          <h5 class="m-0 ms-3">In-Room Amenities</h5>
        </div>  
          <p>
          For your convenience, each room has a flat-screen TV, coffee maker, minibar, and other contemporary amenities.Your stay is designed to exceed expectations, with every detail carefully considered to enhance your overall experience.
          </p> 
      </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-5 px-4">
      <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
        <div class="d-flex align-items-center mb-2">
          <img src="images/images/8.jpg" width="40px">
          <h5 class="m-0 ms-3">Parking Facilities</h5>
        </div>  
          <p>
          Enjoy the convenience of our safe, well-lit parking areas as you settle into your visit. When you explore the city or just unwind at Urban Oasis Suites, you can do so with confidence knowing that our large parking area is constantly under surveillance.
          </p> 
      </div>
    </div>
    <div class="col-lg-4 col-md-6 mb-5 px-4">
      <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
        <div class="d-flex align-items-center mb-2">
          <img src="images/images/img2.jpg.jpg" width="40px">
          <h5 class="m-0 ms-3">Delicious Food </h5>
        </div>  
          <p>
          At Urban Oasis Suites, we recognize wonderful dinner table. Whether you're having a leisurely breakfast, a hearty lunch, or a special dinner for two, our team of talented chefs is committed to making every meal a celebration.
          </p> 
      </div>
    </div>
  </div>
</div>

<?php require('inc/footer.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
