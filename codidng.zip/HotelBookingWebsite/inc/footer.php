<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }

        .container-fluid {
            background-color: #f8f9fa;
        }

        .h-font {
            color: #343a40;
        }

        .footer-link {
            color: #343a40;
            text-decoration: none;
        }

        .footer-link:hover {
            text-decoration: underline;
        }

        .social-icon {
            font-size: 24px;
            margin-right: 10px;
            color: #343a40;
        }

        /* Add this CSS block for the footer */
        .footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
        }
    </style>
    <title>Your Title</title>
</head>
<body>

<div class="container-fluid bg-white mt-5">
    <div class="row">
        <div class="col-lg-4 p-4">
            <h3 class="h-font fw-bold fs-3 mb-2">Urban Oasis Suites</h3>
            <p>Reach out to Urban Oasis Suites with ease if you have any questions or need help. Our hardworking staff is prepared to help you have the best possible stay. Please contact our customer service team, which is available around-the-clock, with any reservations, enquiries about our amenities, or customised requests. You can get in touch with us.</p>
        </div>
        <div class="col-lg-4 p-4">
            <h5 class="mb-3">Links</h5>
            <a href="#" class="d-inline-block mb-2 footer-link">Home</a><br>
            <a href="#" class="d-inline-block mb-2 footer-link">Rooms</a><br>
            <a href="#" class="d-inline-block mb-2 footer-link">Facilities</a><br>
            <a href="#" class="d-inline-block mb-2 footer-link">Contact Us</a><br>
            <a href="#" class="d-inline-block mb-2 footer-link">About</a><br>
          
        </div>
        <div class="col-lg-4 p-4">
            <h5 class="mb-3">Follow us</h5>
            <a href="#" class="d-inline-block mb-2 footer-link" onclick="openInNewTab('https://twitter.com/')">
                <i class="fab fa-twitter social-icon"></i>Twitter
            </a><br>
            <a href="#" class="d-inline-block mb-2 footer-link" onclick="openInNewTab('https://www.facebook.com/')">
                <i class="fab fa-facebook-f social-icon"></i>Facebook
            </a><br>
            <a href="#" class="d-inline-block mb-2 footer-link" onclick="openInNewTab('https://www.instagram.com/')">
                <i class="fab fa-instagram social-icon"></i>Instagram
            </a><br>
        </div>
    </div>
</div>

<div class="footer">
    <h6>Design and Developed by Rozina Wali</h6>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function openInNewTab(url) {
        window.open(url, '_blank');
    }

    function openFeedbackPage() {
    }
</script>
</body>
</html>
